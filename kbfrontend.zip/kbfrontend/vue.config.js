module.exports = {
    devServer: {
      port: 3000
    }
  }